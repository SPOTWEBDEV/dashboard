<?php
define("HOST", "localhost");
define("USER", "root");
define("PASSWORD", "");
define("DATABASE", "indusindnet");

$connection = mysqli_connect(HOST, USER, PASSWORD, DATABASE);

if (!$connection) {
         die('not conneted to databse');
}

session_start();

// $domain = "https://indusind.indusindnet.com/";
$domain = "http://localhost/dashboards/design/";
$redirects = "https://indusindbank.indusindnet.com/corp/BANKAWAY.php";
?>

