<?php

header('location:./dashboard/');

?>
