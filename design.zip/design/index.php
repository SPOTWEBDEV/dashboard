<?php

header('location: ./user/')

?>